﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//using aggiunti
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ComunicazioneSocket
{
    /// <summary>
    /// Andrea Siboni 4L
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            IPEndPoint localendpoint = new IPEndPoint(IPAddress.Parse("192.168.1.16"), 55010);

            Thread t1 = new Thread(new ParameterizedThreadStart(SocketReceive));
            t1.Start(localendpoint);
        }

        public async void SocketReceive (object sourceEndPoint)//ricezione
        {
            IPEndPoint sourceEP = (IPEndPoint)sourceEndPoint;

            Socket t = new Socket(sourceEP.AddressFamily, SocketType.Dgram, ProtocolType.Udp);//creazione oggetto socket

            t.Bind(sourceEP);
            Byte[] bytericevuti = new byte[256];
            string message = "";
            int bytes = 0;

            await Task.Run(() =>//crea la connessione
            {
                while (true)
                {
                    if (t.Available > 0)
                    {
                        message = "";
                        bytes = t.Receive(bytericevuti, bytericevuti.Length, 0);
                        message = message + Encoding.ASCII.GetString(bytericevuti, 0, bytes);

                        this.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            lblRicezione.Content = message;
                        }));
                    }

                }
            });
        }

        private void btnInvia_Click(object sender, RoutedEventArgs e)//invia il messaggio
        {
            try
            {
                IPAddress ipDest = IPAddress.Parse(txtIPAdd.Text);
                int portDest = int.Parse(txtDestport.Text);

                IPEndPoint remoteEndPoint = new IPEndPoint(ipDest, portDest);

                Socket s = new Socket(ipDest.AddressFamily, SocketType.Dgram, ProtocolType.Udp);

                Byte[] byteInviati = Encoding.ASCII.GetBytes(txtMsg.Text);

                s.SendTo(byteInviati, remoteEndPoint);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error" + ex.Message, "ERROR", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnMostraSourceIP_Click(object sender, RoutedEventArgs e)//mostra il source ip in una label
        {
            lblSourceIP.Content = "192.168.1.16";
        }
    }
}